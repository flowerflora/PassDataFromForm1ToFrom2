﻿using SetForm1PropertyFromForm2.Events;
using SetForm1PropertyFromForm2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SetForm1PropertyFromForm2
{
    public partial class Form1 : Form
    {
        //Create new instance of CustomersModel
        List<CustomersModel> Customers = new List<CustomersModel>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();

            //Get list of customers - mimic getting data from database
            Customers = CustomersModel.GetCustomers();
            
            this.PopulateCustomers();
        }

        private void PopulateCustomers()
        {
            //Use LINQ to get customers from the CustomersModel
            var customers = (from c in Customers
                             select c.Customer).ToList();

            //Set the DataSource of the listbox to the customers collection
            this.lstCustomers.DataSource = customers;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //Create new instance of Form2
            Form2 frm2 = new Form2();

            //Pass Customers object to Form2 public property
            frm2.Customers = this.Customers;

            //Access the Event which is used by the Delegate
            //Pass in a method on THIS FORM 
            //This will cause the Deletegate on the Form2 Form
            //To access the method on this Form
            //UpdateCustomers is the Variable declared in Form2
            //CustomersHandler is the delegate declared in Form2
            frm2.UpdateCustomers += new Form2.CustomersHandler(CustomersUpdate);

            //Display Form2
            frm2.ShowDialog();
        }

        private void CustomersUpdate(object s, UpdateCustomersEventArgs e)
        {
            //Get the customers from Form2 which was passed to the
            //UpdateCustomersEventArg class that we created for this
            Customers = e.GetCustomers;

            //Populate the listbox with new changes to Customers
            this.PopulateCustomers();
        }
    }
}
